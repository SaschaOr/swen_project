﻿using System;
using System.Linq.Expressions;

namespace MonsterTradingCardGame
{
    class Program
    {
        static void Main(string[] args)
        {
            Menu mainMenu = new Menu();
            mainMenu.startMainMenu();
        }
    }
}
